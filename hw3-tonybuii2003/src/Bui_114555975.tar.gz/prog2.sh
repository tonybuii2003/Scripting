#!/bin/bash

# Default weights
weights=(1 1 1 1 1)
for ((i = 2; i <= $# && i < 7; i++)); do
    weights[i - 2]=${!i}
done

total_weight=0
for weight in "${weights[@]}"; do
    ((total_weight += weight))
done
num_students=0
score_sum=0
while IFS=',' read -r -a line_array; do
    ((num_students++))
    student_score=0

    for i in {1..5}; do
        ((student_score += line_array[i] * weights[i - 1]))
    done

    result=$((student_score * 1000 / total_weight))
    score_sum=$((score_sum + result))
done < <(tail -n +2 "$1")

average=$((score_sum / num_students))
average_float=$(echo "scale=6; $average/1000" | bc)

echo "Weighted average is $average_float"
