class Array
  end
  
  class Array
  end
  
  b = ["cat","bat","mat","sat"]
  print b.map(-10..10) { |x| x[0].upcase + x[1,x.length] }, "\n"
  
  