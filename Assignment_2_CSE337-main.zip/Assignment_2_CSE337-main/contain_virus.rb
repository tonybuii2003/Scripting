def contain_virus(grid)   
end

isInfected = [[0,1,0,0],[1,1,1,0],[0,1,0,0],[1,1,0,0]]

# Call the function and store the result in a variable
result = contain_virus(isInfected)

# Print the result
puts "Number of walls needed: #{result}"