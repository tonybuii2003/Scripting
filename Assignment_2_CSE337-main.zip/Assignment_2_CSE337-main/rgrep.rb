#!/usr/bin/env ruby
# args = ARGF.argv
args = ARGV