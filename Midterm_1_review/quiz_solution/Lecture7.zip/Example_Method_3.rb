# Ruby program to illustrate method return statement


def num

# variables of method
a = 10
b = 39

sum = a + b

# return the value of the sum
return sum

end

# calling of num method
puts "The result is: #{num}"
