# The Book of Ruby - http://www.sapphiresteel.com
def fred
	puts( "Hello from fred" )
end

def Fred
	puts( "And hello from Fred" )
end

fred
# Fred  #<= error!
Fred()