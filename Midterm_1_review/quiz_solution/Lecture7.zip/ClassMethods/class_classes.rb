# The Book of Ruby - http://www.sapphiresteel.com

class MyClass
			
end

puts( MyClass.class )
puts( String.class )
puts( Object.class )
puts( Class.class )
puts( IO.class )

p( IO.singleton_methods )
