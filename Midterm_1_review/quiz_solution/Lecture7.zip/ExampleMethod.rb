def sayGoodnight(name)  
result = "Goodnight, " + name  
return result  
end 


# method calls 
sayGoodnight "John-Boy"  
sayGoodnight("Mary-Ellen")
