def sayGoodnight(name)  
result = "Goodnight, " + name  
return result  
end 


# method calls 
p sayGoodnight "John-Boy"  
p sayGoodnight("Mary-Ellen")
