def something
  'hello'
end

p something
#==> hello
something= 'Ruby'
p something
#==> Ruby #'hello' is not printed
