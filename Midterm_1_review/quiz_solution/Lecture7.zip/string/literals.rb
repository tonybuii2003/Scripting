# The Book of Ruby - http://www.sapphiresteel.com

p %q/dog cat #{1+2}/
p %Q/dog cat #{1+2}/
p %/dog cat #{1+2}/
p %w/dog cat #{1+2}/
p %W/dog cat #{1+2}/
p %r|^[a-z]*$|
p %s/dog/
p %x/vol/ #<= Shows volume on Windows (try other commands on other OSes) 