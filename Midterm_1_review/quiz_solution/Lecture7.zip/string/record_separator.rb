# The Book of Ruby - http://www.sapphiresteel.com

puts (' Enter "had we but world enough and time" ')
s = gets()
puts ( s )

$/ = "world" # redefine record separator
puts (' Enter "had we but world enough and time" ')
s = gets()
puts( s )
