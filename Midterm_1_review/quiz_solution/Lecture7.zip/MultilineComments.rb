# for single line
# ruby has multi line comments

=begin

I 
am 
writing this just
to show the how multi line works

=end

puts " Multi line comments work!"