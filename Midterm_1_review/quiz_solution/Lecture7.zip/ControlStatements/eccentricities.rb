# The Book of Ruby - http://www.sapphiresteel.com

puts( 1==1 )
puts( 1!=1 )
puts( !(1==1) )
puts( (not( 1==1 )) )
# puts( not( 1==1 ) )	# syntax error in Ruby 1.8 but ok in Ruby 1.9
puts( true && true && !(true) )
# puts( true && true and !(true) ) 
puts( true && true )
puts( ((true) and (true)) )
# puts( true and true ) 