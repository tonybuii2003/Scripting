# The Book of Ruby - http://www.sapphiresteel.com

p( Dir.entries( 'C:\\' ) )
