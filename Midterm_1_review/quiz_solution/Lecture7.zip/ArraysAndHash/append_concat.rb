

a =[1,2,3]
b =[4,5,6]
c = a + b	# concatenate
print( "c=#{c.inspect}\n" )
print( "a=#{a.inspect}\n" )
a << b		# append
print( "a=#{a.inspect}\n" )
print( "a.flatten=#{a.flatten.inspect}\n" )