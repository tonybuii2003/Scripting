# The Book of Ruby - http://www.sapphiresteel.com


p([1,2,3]<=>[1,2,3,4])
p([2,3,4]<=>[1,2,3,4])


p([1,2,3].length<=>[1,2,3,4].length)
p([2,3,4].length<=>[1,2,3,4].length)