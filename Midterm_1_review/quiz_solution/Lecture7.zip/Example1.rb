# Ruby program to illustrate the use
# of true and false
a = 4
b = 4

if a == b
	
	# If Condition is true
	puts "True! a and b are equal"
	
else
	
	# If Condition is false
	puts "False! a and b are not equal"
	
end
