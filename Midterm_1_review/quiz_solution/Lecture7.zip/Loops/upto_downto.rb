# The Book of Ruby - http://www.sapphiresteel.com

0.upto(10) do
	| i |
	puts( i )
end

10.downto(0) do
	| i |
	puts( i )
end