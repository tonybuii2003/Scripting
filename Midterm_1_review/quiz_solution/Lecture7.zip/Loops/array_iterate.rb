# The Book of Ruby - http://www.sapphiresteel.com


arr= [1,2,3,4,5]
i = 0

while i < arr.length
   puts(arr[i])
   i += 1
end

i=0
until i == arr.length
   puts(arr[i])
   i +=1
end
